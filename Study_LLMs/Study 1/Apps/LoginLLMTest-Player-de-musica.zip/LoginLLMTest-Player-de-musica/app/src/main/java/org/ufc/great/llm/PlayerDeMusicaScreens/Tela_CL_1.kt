package org.ufc.great.llm.PlayerDeMusicaScreens

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.PlayerDeMusica.loginllmtest.R

class Tela_CL_1 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tela_cl1)
    }
}